package com.company.govt.cs;
import com.company.govt.*;
public class CivilServices implements Government{
    @Override
    public void jobs() {
        System.out.println("Indian Administrative Service");
    }
}
