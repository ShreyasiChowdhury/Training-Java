package com.company.govt.test;
import com.company.govt.cs.*;
import com.company.govt.ms.*;

public class Test{
    public static void main(String[] args) {
        CivilServices csobj=new CivilServices();
        csobj.jobs();
        MilitaryServices msobj=new MilitaryServices();
        msobj.jobs();
    }
}
