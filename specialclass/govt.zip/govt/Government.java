package com.company.govt;

public interface Government {
    void jobs();
}
