package com.company.govt.ms;
import com.company.govt.*;
public class MilitaryServices implements Government {
    @Override
    public void jobs() {
        System.out.println("Lieutenant General");
    }
}
